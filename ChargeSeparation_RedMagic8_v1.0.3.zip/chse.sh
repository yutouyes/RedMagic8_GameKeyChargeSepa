#!/bin/bash
while true
do
a=$(dumpsys battery get status)
b=$(cat /sys/bus/platform/drivers/gpio-keys_nubia/soc:gpio_keys_nubia/GamekeyStatus)
c=$(settings get global charge_separation_switch)
if [ "$a" -eq 3 ]
then
if [ "$c" -eq 1 ]
then
settings put global charge_separation_switch 0
fi
else
if [ "$b" -eq 0 ]
then
if [ "$c" -eq 1 ]
then
settings put global charge_separation_switch 0
fi
else
if [ "$c" -eq 0 ]
then
settings put global charge_separation_switch 1
fi
fi
fi
sleep 1s
done
exit 0
