sleep 10
MODDIR=${0%/*}
chmod 0755 "$MODDIR/chse.sh"
/system/bin/sh $MODDIR/chse.sh 2>&1 >/dev/null &
exit 0